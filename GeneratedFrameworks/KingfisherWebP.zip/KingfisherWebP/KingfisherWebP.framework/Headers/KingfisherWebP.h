//
//  KingfisherWebP.h
//  KingfisherWebP
//
//  Created by yeatse on 2020/12/22.
//

#import <Foundation/Foundation.h>

//! Project version number for KingfisherWebP.
FOUNDATION_EXPORT double KingfisherWebPVersionNumber;

//! Project version string for KingfisherWebP.
FOUNDATION_EXPORT const unsigned char KingfisherWebPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KingfisherWebP/PublicHeader.h>
#import <KingfisherWebP/CGImage+WebP.h>
